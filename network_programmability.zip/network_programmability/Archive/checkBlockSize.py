def check_block_size(subnet_mask):
    if('128' in subnet_mask):
        return 128
    elif('192' in subnet_mask):
        return 64
    elif('224' in subnet_mask):
        return 32
    elif('240' in subnet_mask):
        return 16
    elif('248' in subnet_mask):
        return 8
    elif('252' in subnet_mask):
        return 4
    elif('254' in subnet_mask):
        return 2
    else:
        return 1
